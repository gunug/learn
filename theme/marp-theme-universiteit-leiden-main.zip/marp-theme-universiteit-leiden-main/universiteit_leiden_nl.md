---
marp: true
theme: universiteit_leiden_16:9
paginate: true
footer: Universiteit Leiden. Bij ons leer je de wereld kennen
---
<!-- _class: title-slide -->
<!-- _footer: Bij ons leer je de wereld kennen -->

# Titel presentatie

Naam spreker | Plaats

![h:37mm w:66.7mm](https://huisstijl.leidenuniv.nl/assets/files/ul-algemeen-rgb-kleur.png)

---
<!-- _class: toc -->

## Inhoudsopgave

1. Hoofdstuk
2. Hoofdstuk
    - sectie 2a
    - sectie 2b
3. Hoofdstuk

![example](https://fakeimg.pl/600x1200/e7e9f2/?text=afbeelding&font=bebas)

---
## Alleen tekst
Occaecat deserunt fugiat laboris occaecat enim ex consectetur exercitation do ipsum ea ad labore magna. Mollit reprehenderit ipsum voluptate consequat nulla labore sit consectetur magna commodo est sit nulla pariatur. Excepteur eiusmod elit voluptate elit sunt deserunt veniam dolore. Commodo ex exercitation adipisicing do amet anim aute. Ex veniam ut est deserunt anim. Pariatur ullamco magna eu cillum eu amet anim laborum.


---
<!-- _class: t75-i25 -->
## Tekst dominant en beeld 75%/25%
Cupidatat incididunt aliqua Lorem laboris ex laboris esse aute ut dolore laborum. Reprehenderit excepteur dolor duis dolor. Adipisicing ea cillum elit commodo adipisicing non quis labore sunt nulla reprehenderit elit. Cupidatat velit commodo consequat aute nisi laboris aliqua est culpa aute consequat commodo. Laboris in eiusmod laboris occaecat ex pariatur nisi est irure commodo anim. Occaecat occaecat sint ipsum Lorem pariatur velit nostrud ullamco aliqua duis pariatur adipisicing excepteur.

![example](https://fakeimg.pl/300x600/e7e9f2/?text=afbeelding&font=bebas)

---
## Tekst en beeld gelijk; 50%/50%
<!-- _class: t50-i50 -->
Id mollit tempor sunt in enim sit esse labore Lorem quis. Quis Lorem adipisicing Lorem enim sit. Elit officia ullamco ea exercitation non Lorem laboris consectetur qui incididunt qui dolor. Esse ad aute exercitation enim do est do dolor laboris deserunt. Occaecat adipisicing ut sint esse. Dolor ex ullamco non Lorem.

![example](https://fakeimg.pl/600x800/e7e9f2/?text=afbeelding&font=bebas)

---
## Beeld dominant, tekst 25%
<!-- _class: t25-i75 -->
Proident consectetur labore culpa magna irure et aliqua nostrud reprehenderit. Nisi amet ullamco commodo laborum. Excepteur id et fugiat ullamco velit dolore occaecat officia excepteur nisi non occaecat. Occaecat et duis exercitation Lorem ipsum sit est pariatur ut ipsum.

![example](https://fakeimg.pl/900x450/e7e9f2/?text=afbeelding&font=bebas)

---
## Alleen beeld
![example](https://fakeimg.pl/1280x720/e7e9f2/?text=afbeelding&font=bebas)

---
<!-- _class: title-slide -->
<!-- _footer: Bij ons leer je de wereld kennen -->

# Titel afsluiting

![h:37mm w:66.7mm](https://huisstijl.leidenuniv.nl/assets/files/ul-algemeen-rgb-kleur.png)
