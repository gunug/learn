---
marp: true
theme: universiteit_leiden_16:9
paginate: true
footer: Discover the world at Leiden University
---
<!-- _class: title-slide -->

# Title Presentation

Name speaker | Place

![h:37mm w:66.7mm](https://huisstijl.leidenuniv.nl/assets/files/ul-algemeen-internationaal-rgb-color.png)

---
<!-- _class: toc -->

## Table of Contents

1. Chapter
2. Chapter
    - section 2a
    - section 2b
3. Chapter

![example](https://fakeimg.pl/600x1200/e7e9f2/?text=image&font=bebas)

---
## Just text
Occaecat deserunt fugiat laboris occaecat enim ex consectetur exercitation do ipsum ea ad labore magna. Mollit reprehenderit ipsum voluptate consequat nulla labore sit consectetur magna commodo est sit nulla pariatur. Excepteur eiusmod elit voluptate elit sunt deserunt veniam dolore. Commodo ex exercitation adipisicing do amet anim aute. Ex veniam ut est deserunt anim. Pariatur ullamco magna eu cillum eu amet anim laborum.


---
<!-- _class: t75-i25 -->
## Text dominant with image 75%/25%
Cupidatat incididunt aliqua Lorem laboris ex laboris esse aute ut dolore laborum. Reprehenderit excepteur dolor duis dolor. Adipisicing ea cillum elit commodo adipisicing non quis labore sunt nulla reprehenderit elit. Cupidatat velit commodo consequat aute nisi laboris aliqua est culpa aute consequat commodo. Laboris in eiusmod laboris occaecat ex pariatur nisi est irure commodo anim. Occaecat occaecat sint ipsum Lorem pariatur velit nostrud ullamco aliqua duis pariatur adipisicing excepteur.

![example](https://fakeimg.pl/300x450/e7e9f2/?text=image&font=bebas)

---
## Text and image; 50%/50%
<!-- _class: t50-i50 -->
Id mollit tempor sunt in enim sit esse labore Lorem quis. Quis Lorem adipisicing Lorem enim sit. Elit officia ullamco ea exercitation non Lorem laboris consectetur qui incididunt qui dolor. Esse ad aute exercitation enim do est do dolor laboris deserunt. Occaecat adipisicing ut sint esse. Dolor ex ullamco non Lorem.

![example](https://fakeimg.pl/600x800/e7e9f2/?text=image&font=bebas)

---
## Image dominant, text 25%
<!-- _class: t25-i75 -->
Proident consectetur labore culpa magna irure et aliqua nostrud reprehenderit. Nisi amet ullamco commodo laborum. Excepteur id et fugiat ullamco velit dolore occaecat officia excepteur nisi non occaecat. Occaecat et duis exercitation Lorem ipsum sit est pariatur ut ipsum.

![example](https://fakeimg.pl/900x450/e7e9f2/?text=image&font=bebas)

---
## Image
![example](https://fakeimg.pl/1280x720/e7e9f2/?text=image&font=bebas)

---
<!-- _class: title-slide -->

# Title Closure

![h:37mm w:66.7mm](https://huisstijl.leidenuniv.nl/assets/files/ul-algemeen-internationaal-rgb-color.png)
